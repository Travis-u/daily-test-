# Maki · 后台音频与自定义讲座闹钟（Android）

版本：0.4.0 源码工程；**并非原 Maki 2.8 的升级包**。

## 能实际实现的功能（源代码已接线，待 Android 构建／真机验证）

- 独立 Android App 主界面：导入手机本地音频、播放、停止、进入闹钟设置。
- Media3 ExoPlayer + MediaSessionService：切换应用、锁屏时持续播放已授权的直接音频；提供系统媒体通知及控制。
- 多个闹钟：24 小时时间、周一至周日重复或单次、开关/编辑/删除。
- 按时间自动播放：从已导入音频指定选择、续播上次或随机选择。
- 目标音量、30 秒渐强、播放 10~240 分钟后自动停止或不限制、停止与贪睡 10 分钟。
- 内置本地备用铃声：联网或音频加载失败时继续响铃（但厂商后台限制可能影响实际触发）。
- Android 12+ 精确闹钟权限引导、Android 13+ 通知权限引导；重启/改时间/改时区后重排已设闹钟。

## 无法声称已经实现

- **B站官方网页视频在锁屏后继续播放，以及定时直接自动播放网页视频**：原 Maki 2.8 使用嵌入式 B 站 WebView 播放器，当前没有它的授权媒体直链、平台后台播放能力或原始完整工程，因而不能把网页 URL 当作音频 URI。
- **与原 Maki 2.8 覆盖升级**：旧工程、签名密钥与学习数据结构尚未拿到。为了不覆盖、清除旧 Maki，此独立版故意使用包名 `com.makiplayer.companion`。
- **已经成功安装/运行**：当前环境没有 Android SDK 和可用模拟器/真机。本项目仅有纯 Java 闹钟时间计算的本地测试结果。GitHub Actions 构建脚本已提供，但未运行。

## 工程结构

```text
MakiAudioAlarm-standalone/
├── app/                                # 独立 App 入口和音频列表
├── maki-audioalarm/                    # 后台 MediaSessionService + 闹钟模块
├── settings.gradle / build.gradle
└── .github/workflows/                 # Android CI构建脚本（需仓库环境启用）
```

## 构建方式

环境：Android Studio、JDK 17、Android SDK 36、Android Gradle Plugin 8.11.1、Gradle 8.13。

```
gradle :app:assembleDebug
```

APK 输出路径：`app/build/outputs/apk/debug/app-debug.apk`。

纯 Java 逻辑测试：

```
bash maki-audioalarm/tests/run_model_tests.sh
```

## 注意

系统的“闹钟和提醒”特殊权限须由用户自行允许，否则不会承诺准时响起；部分手机还需要允许自启动和后台活动。第一次使用务必测试锁屏、重启、静音/勿扰模式及长时间待机的实际行为。**尚未通过真机测试前，不应将其作为唯一的起床闹钟。**

如需最终整合回 Maki 2.8：恢复旧 `MakiPlayer-source.zip`、原应用签名与回归设备；此模块不触碰旧持久数据文件 `schema2`、`learning-v2.json`。
