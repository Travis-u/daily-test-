package com.makiplayer.companion;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.makiplayer.app.audioalarm.AlarmMediaCatalog;
import com.makiplayer.app.audioalarm.MakiPlayback;
import java.util.List;

/** Standalone companion. Intentionally a separate package: never overwrites Maki's data/signature. */
public final class MainActivity extends Activity {
    private static final int PICK_AUDIO = 98;
    private LinearLayout root;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad=dp(18);root.setPadding(pad,pad,pad,pad);
        scroll.addView(root);
        setContentView(scroll);
        draw();
    }
    @Override protected void onResume(){super.onResume(); if(root!=null)draw();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void label(String s,int size){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,dp(8),0,dp(10));root.addView(t);
    }
    private void button(String s,View.OnClickListener f){Button b=new Button(this);b.setText(s);b.setOnClickListener(f);root.addView(b);}
    private void draw(){
        root.removeAllViews();
        label("Maki · 讲座音频",26);
        label("后台音频播放与可自定义闹钟。此独立版不会覆盖原 Maki 或修改旧笔记。",14);
        button("⏰ 管理讲座闹钟",v->MakiPlayback.openAlarmEditor(this));
        button("＋ 导入本地音频",v->pick());
        button("■ 停止播放",v->MakiPlayback.stop(this));
        label("已导入音频（可锁屏播放）",19);
        List<AlarmMediaCatalog.Item> entries=new AlarmMediaCatalog(this).list();
        if(entries.isEmpty())label("音频库为空。选择手机中的 MP3 / M4A 等文件后，点击即可播放。",14);
        for(AlarmMediaCatalog.Item item:entries){
            button("▶  "+item.title,v->{
                try{MakiPlayback.play(this,item.title,item.uri,0);}
                catch(RuntimeException e){Toast.makeText(this,"无法播放，请重新导入音频",Toast.LENGTH_LONG).show();}
            });
        }
        label("说明：B站网页并非可直接播放的授权音频地址。该版本不支持网页视频锁屏音频；闹钟无法加载指定媒体时会尝试内置铃声。请先用手机系统闹钟作备份。",13);
    }
    private void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("audio/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_AUDIO);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=PICK_AUDIO||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
        String title="本地音频";
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(c!=null&&c.moveToFirst())title=c.getString(0);
        }catch(Exception ignored){}
        try{new AlarmMediaCatalog(this).add(title,uri.toString());draw();
            Toast.makeText(this,"已加入音频库",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"导入失败",Toast.LENGTH_LONG).show();}
    }
}
