package com.makiplayer.app.audioalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.media.AudioAttributes;
import android.provider.Settings;

public final class AlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_FIRE="com.makiplayer.app.alarm.FIRE";
    public static final String ACTION_SNOOZE_FIRE="com.makiplayer.app.alarm.SNOOZE_FIRE";
    @Override public void onReceive(Context c,Intent i){
        if(i==null)return;
        boolean snoozed=ACTION_SNOOZE_FIRE.equals(i.getAction());
        if(!snoozed&&!ACTION_FIRE.equals(i.getAction()))return;
        int id= i.getData()==null?-1:parseInt(i.getData().getLastPathSegment());
        AlarmStore store=new AlarmStore(c);AlarmSpec a=store.find(id);
        if(a==null||(!a.enabled&&!snoozed))return;
        if(!snoozed){
            if(a.weekdaysMask==0){store.put(a.withEnabled(false));}
            else AlarmScheduler.schedule(c,a); // next weekly occurrence
        }
        Intent service=new Intent(c,AlarmPlaybackService.class)
            .setAction(AlarmPlaybackService.ACTION_ALARM).putExtra(AlarmPlaybackService.EXTRA_ID,id);
        try {
            if(Build.VERSION.SDK_INT>=26)c.startForegroundService(service);else c.startService(service);
        }catch(RuntimeException e){
            // Android may block background FGS on restricted devices; alarm notification/receiver remains testable.
            android.util.Log.e("MakiAlarm","Alarm foreground service start failed",e);
            alertFallback(c,id);
        }
    }
    private static void alertFallback(Context c,int id){
        // Last-ditch audible system notification if an OEM rejects FGS launch.
        // Requires user's Android 13+ notification permission; cannot bypass device policy.
        final String channel="maki_emergency_alarm_v1";
        NotificationManager manager=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(channel,"Maki 闹钟应急提醒",NotificationManager.IMPORTANCE_HIGH);
            nc.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI,
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            manager.createNotificationChannel(nc);
        }
        Intent screen=new Intent(c,AlarmEditorActivity.class).putExtra("alarmId",id);
        PendingIntent show=PendingIntent.getActivity(c,id,screen,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
        Notification notice=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Maki 讲座闹钟").setContentText("后台播放器受限制，请打开闹钟")
            .setContentIntent(show).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_ALARM).build();
        try{manager.notify(80000+id,notice);}catch(SecurityException ignored){}
    }
    private static int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return -1;}}
}
