package com.makiplayer.app.audioalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

/** Uses exact, user-visible alarm clocks; never schedules a fake inexact alarm silently. */
public final class AlarmScheduler {
    private AlarmScheduler(){}
    private static AlarmManager manager(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
    public static boolean canSchedule(Context c){return Build.VERSION.SDK_INT<31||manager(c).canScheduleExactAlarms();}
    private static PendingIntent receiver(Context c,int id,String action){
        Intent i=new Intent(c,AlarmReceiver.class).setAction(action).setData(Uri.parse("maki-alarm://trigger/"+id));
        return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent show(Context c,int id){
        Intent i=new Intent(c,AlarmEditorActivity.class).setAction("com.makiplayer.app.alarm.EDIT").putExtra("alarmId",id);
        return PendingIntent.getActivity(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void cancel(Context c,int id){
        PendingIntent p=receiver(c,id,AlarmReceiver.ACTION_FIRE);
        manager(c).cancel(p);
        // Snooze uses a separate request code and action, so it doesn't replace weekly schedule.
        manager(c).cancel(receiver(c,id,AlarmReceiver.ACTION_SNOOZE_FIRE));
    }
    public static boolean schedule(Context c,AlarmSpec spec){
        manager(c).cancel(receiver(c,spec.id,AlarmReceiver.ACTION_FIRE));
        if(!spec.enabled)return true;
        if(!canSchedule(c))return false;
        try {
            manager(c).setAlarmClock(new AlarmManager.AlarmClockInfo(spec.nextOccurrence(System.currentTimeMillis()),show(c,spec.id)),receiver(c,spec.id,AlarmReceiver.ACTION_FIRE));
            return true;
        } catch (SecurityException permissionRevoked) {
            return false;
        }
    }
    public static boolean snooze(Context c,int id,int minutes){
        if(!canSchedule(c))return false;
        long at=System.currentTimeMillis()+minutes*60_000L;
        try {
            manager(c).setAlarmClock(new AlarmManager.AlarmClockInfo(at,show(c,id)),receiver(c,id,AlarmReceiver.ACTION_SNOOZE_FIRE));
            return true;
        } catch (SecurityException permissionRevoked) {
            return false;
        }
    }
    public static boolean rescheduleAll(Context c){
        boolean ok=true;for(AlarmSpec a:new AlarmStore(c).list())if(!schedule(c,a))ok=false;return ok;
    }
}
