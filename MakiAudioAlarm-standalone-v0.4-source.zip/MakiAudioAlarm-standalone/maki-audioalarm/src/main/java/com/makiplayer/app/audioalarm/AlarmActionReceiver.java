package com.makiplayer.app.audioalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class AlarmActionReceiver extends BroadcastReceiver {
    public static final String STOP="com.makiplayer.app.alarm.STOP";
    public static final String SNOOZE="com.makiplayer.app.alarm.SNOOZE";
    @Override public void onReceive(Context c,Intent in){
        if(in==null)return;
        String action=in.getAction();if(!STOP.equals(action)&&!SNOOZE.equals(action))return;
        int id=in.getIntExtra(AlarmPlaybackService.EXTRA_ID,-1);
        Intent stop=new Intent(c,AlarmPlaybackService.class).setAction(AlarmPlaybackService.ACTION_STOP);
        // Already foreground during an alarm; deliver as a normal start to the running service.
        try{c.startService(stop);}catch(RuntimeException e){android.util.Log.e("MakiAlarm","stop failed",e);}
        if(SNOOZE.equals(action)&&id>0)AlarmScheduler.snooze(c,id,10);
    }
}
