package com.makiplayer.app.audioalarm;

import android.content.Context;
import android.content.Intent;

/** Integration seam: call ONLY for user-selected or permitted, directly playable media. */
public final class MakiPlayback {
    private MakiPlayback(){}
    public static void play(Context c,String title,String directUri,long startMs){
        AlarmMediaCatalog catalog=new AlarmMediaCatalog(c);
        catalog.add(title,directUri);catalog.saveLast(title,directUri,startMs);
        Intent i=new Intent(c,AlarmPlaybackService.class).setAction(AlarmPlaybackService.ACTION_PLAY)
            .putExtra(AlarmPlaybackService.EXTRA_URI,directUri)
            .putExtra(AlarmPlaybackService.EXTRA_TITLE,title)
            .putExtra(AlarmPlaybackService.EXTRA_POSITION,Math.max(0,startMs));
        c.startService(i); // call from visible Activity; service becomes foreground through Media3 playback
    }
    public static void openAlarmEditor(Context c){
        Intent i=new Intent(c,AlarmEditorActivity.class);
        if(!(c instanceof android.app.Activity))i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
    public static void stop(Context c){
        c.startService(new Intent(c,AlarmPlaybackService.class).setAction(AlarmPlaybackService.ACTION_STOP));
    }
}
