package com.makiplayer.app.audioalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaPlayer;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

/** Native authorised-audio playback + reliable local-ring fallback. Not a Bilibili WebView extractor. */
public final class AlarmPlaybackService extends MediaSessionService {
    public static final String ACTION_ALARM="com.makiplayer.app.audioalarm.ALARM";
    public static final String ACTION_PLAY="com.makiplayer.app.audioalarm.PLAY";
    public static final String ACTION_STOP="com.makiplayer.app.audioalarm.STOP";
    public static final String EXTRA_ID="alarmId", EXTRA_URI="mediaUri", EXTRA_TITLE="mediaTitle", EXTRA_POSITION="positionMs";
    private static final int ALARM_NOTICE=7018;
    private static final String CHANNEL="maki_lecture_alarm";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private ExoPlayer player;
    private MediaSession session;
    private MediaPlayer backupRing;
    private int alarmId=-1, targetPercent=60;
    private boolean alarmActive=false, alarmFade=true, nativeAudioStarted=false;
    private long fadeStartMs=0;
    private String activeUri="", activeTitle="";
    private Runnable stopRunnable;
    private final Runnable fadeRunnable=new Runnable(){@Override public void run(){
        if(!alarmActive)return;
        float amount=Math.min(1f,0.15f+0.85f*(android.os.SystemClock.elapsedRealtime()-fadeStartMs)/30000f);
        float level=(targetPercent/100f)*(alarmFade?amount:1f);
        if(backupRing!=null)backupRing.setVolume(level,level);
        if(nativeAudioStarted)player.setVolume(level);
        handler.postDelayed(this,1000L);
    }};
    private final Runnable positionRunnable=new Runnable(){@Override public void run(){
        if(player!=null&&player.getMediaItemCount()>0&&player.getPlaybackState()!=Player.STATE_IDLE&&AlarmMediaCatalog.supported(activeUri)){
            new AlarmMediaCatalog(AlarmPlaybackService.this).saveLast(activeTitle,activeUri,player.getCurrentPosition());
        }
        handler.postDelayed(this,15000L);
    }};

    @Override public void onCreate(){
        super.onCreate();
        player=new ExoPlayer.Builder(this).build();
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),true);
        session=new MediaSession.Builder(this,player).build();
        createChannel();
        player.addListener(new Player.Listener(){
            @Override public void onIsPlayingChanged(boolean playing){
                if(playing&&alarmActive&&player.getCurrentTracks().isTypeSelected(C.TRACK_TYPE_AUDIO)){
                    nativeAudioStarted=true;
                    releaseBackup();
                    player.setVolume((targetPercent/100f)*(alarmFade?0.15f:1f));
                }
            }
            @Override public void onPlayerError(PlaybackException error){
                Log.w("MakiAlarm","Direct media unavailable; local alarm remains active",error);
                if(!alarmActive){stopSelf();}
            }
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_ENDED && alarmActive) stopAlarm();
            }
        });
        handler.postDelayed(positionRunnable,15000L);
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo){return session;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        super.onStartCommand(intent,flags,startId);
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(ACTION_STOP.equals(action)){stopAlarm();return START_NOT_STICKY;}
        if(ACTION_ALARM.equals(action)){
            int id=intent.getIntExtra(EXTRA_ID,-1);
            AlarmSpec a=new AlarmStore(this).find(id);
            if(a!=null)startAlarm(a);
            else stopSelf();
        }else if(ACTION_PLAY.equals(action)){
            String uri=intent.getStringExtra(EXTRA_URI),title=intent.getStringExtra(EXTRA_TITLE);
            long position=intent.getLongExtra(EXTRA_POSITION,0);
            if(AlarmMediaCatalog.supported(uri)){
                clearAlarmState();
                playNative(title,uri,position);
            }else stopSelf();
        }
        return START_NOT_STICKY;
    }
    private void startAlarm(AlarmSpec a){
        clearAlarmState();
        alarmActive=true;alarmId=a.id;targetPercent=a.targetVolume;alarmFade=a.gradualVolume;
        fadeStartMs=android.os.SystemClock.elapsedRealtime();
        Notification alert=alarmNotification("讲座闹钟已响起",a.id);
        if(Build.VERSION.SDK_INT>=29)startForeground(ALARM_NOTICE,alert,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(ALARM_NOTICE,alert);
        playBackup();
        handler.post(fadeRunnable);
        if(a.durationMinutes>0){
            stopRunnable=this::stopAlarm;
            handler.postDelayed(stopRunnable,a.durationMinutes*60000L);
        }
        AlarmMediaCatalog catalog=new AlarmMediaCatalog(this);
        AlarmMediaCatalog.Item item=catalog.resolve(a);
        if(item!=null){
            long startMs=AlarmSpec.CONTINUE.equals(a.sourceMode)?catalog.lastPositionMs():0;
            playNative(item.title,item.uri,startMs);
            handler.postDelayed(()->{
                if(alarmActive&&!nativeAudioStarted)player.stop(); // retain local ringtone after network timeout
            },20_000L);
        }
    }
    private void playNative(String title,String uri,long positionMs){
        activeUri=uri;activeTitle=(title==null||title.isEmpty())?"讲座音频":title;
        new AlarmMediaCatalog(this).saveLast(activeTitle,uri,Math.max(0,positionMs));
        player.setMediaItem(new MediaItem.Builder().setUri(Uri.parse(uri))
            .setMediaMetadata(new MediaMetadata.Builder().setTitle(activeTitle).build()).build());
        if(alarmActive) player.setVolume((targetPercent/100f)*(alarmFade?0.15f:1f));
        else player.setVolume(1f);
        player.prepare();
        if(positionMs>0)player.seekTo(positionMs);
        player.play();
    }
    private void playBackup(){
        try {
            backupRing=new MediaPlayer();
            backupRing.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.maki_alarm_fallback);
            backupRing.setDataSource(this,uri);
            backupRing.setLooping(true);backupRing.prepare();
            float v=(targetPercent/100f)*(alarmFade?0.15f:1f);
            backupRing.setVolume(v,v);backupRing.start();
        }catch(Exception e){Log.e("MakiAlarm","Local fallback ringtone failed",e);releaseBackup();}
    }
    private void releaseBackup(){
        if(backupRing!=null){try{backupRing.stop();}catch(Exception ignored){}backupRing.release();backupRing=null;}
    }
    private void clearAlarmState(){
        if(player!=null&&player.getPlaybackState()!=Player.STATE_IDLE&&AlarmMediaCatalog.supported(activeUri)){
            new AlarmMediaCatalog(this).saveLast(activeTitle,activeUri,player.getCurrentPosition());
        }
        if(stopRunnable!=null){handler.removeCallbacks(stopRunnable);stopRunnable=null;}
        handler.removeCallbacks(fadeRunnable);
        alarmActive=false;alarmId=-1;nativeAudioStarted=false;
        releaseBackup();
        if(player!=null)player.stop();
    }
    private void stopAlarm(){
        clearAlarmState();
        if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf();
    }
    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"Maki 讲座闹钟",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("播放讲座闹钟及离线备用提示音");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private PendingIntent action(String action,int id){
        Intent i=new Intent(this,AlarmActionReceiver.class).setAction(action).putExtra(EXTRA_ID,id)
            .setData(Uri.parse("maki-alarm://control/"+id+"/"+action));
        return PendingIntent.getBroadcast(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification alarmNotification(String text,int id){
        Intent screen=new Intent(this,AlarmEditorActivity.class).putExtra("alarmId",id);
        PendingIntent open=PendingIntent.getActivity(this,id,screen,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Maki · 讲座闹钟")
            .setContentText(text).setContentIntent(open).setOngoing(true)
            .setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_ALARM)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"停止",action(AlarmActionReceiver.STOP,id)).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_lock_idle_alarm,"贪睡10分钟",action(AlarmActionReceiver.SNOOZE,id)).build())
            .build();
    }
    @Override public void onDestroy(){
        clearAlarmState();
        handler.removeCallbacks(positionRunnable);
        if(session!=null){session.release();session=null;}
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
