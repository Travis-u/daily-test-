package com.makiplayer.app.audioalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Rehydrate recurring alarms after reboot, date/time changes, upgrade and exact-alarm grant. */
public final class AlarmRescheduleReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(i!=null && i.getAction()!=null) AlarmScheduler.rescheduleAll(c);
    }
}
