package com.makiplayer.app.audioalarm;

import java.util.Calendar;

/** The alarm model is independent of the existing Maki learning-data schema. */
public final class AlarmSpec {
    public static final String CONTINUE = "continue";
    public static final String SPECIFIC = "specific";
    public static final String RANDOM = "random";
    /** Weekday bit 0=Monday, 1=Tuesday, ..., 6=Sunday; 0 means one time. */
    public final int id, hour, minute, weekdaysMask, durationMinutes, targetVolume;
    public final boolean enabled, gradualVolume;
    public final String sourceMode, title, mediaUri;

    public AlarmSpec(int id, int hour, int minute, int weekdaysMask, boolean enabled,
                     int durationMinutes, int targetVolume, boolean gradualVolume,
                     String sourceMode, String title, String mediaUri) {
        if (id <= 0 || hour < 0 || hour > 23 || minute < 0 || minute > 59 || weekdaysMask < 0 || weekdaysMask > 127)
            throw new IllegalArgumentException("invalid alarm identity/time/repeat");
        if (durationMinutes < 0 || durationMinutes > 240 || targetVolume < 10 || targetVolume > 100)
            throw new IllegalArgumentException("invalid duration or volume");
        if (!CONTINUE.equals(sourceMode) && !SPECIFIC.equals(sourceMode) && !RANDOM.equals(sourceMode))
            throw new IllegalArgumentException("invalid source mode");
        this.id=id; this.hour=hour; this.minute=minute; this.weekdaysMask=weekdaysMask;
        this.enabled=enabled; this.durationMinutes=durationMinutes; this.targetVolume=targetVolume;
        this.gradualVolume=gradualVolume; this.sourceMode=sourceMode;
        this.title=title==null?"":title; this.mediaUri=mediaUri==null?"":mediaUri;
    }

    public AlarmSpec withEnabled(boolean on) {
        return new AlarmSpec(id,hour,minute,weekdaysMask,on,durationMinutes,targetVolume,gradualVolume,sourceMode,title,mediaUri);
    }

    /** Next occurrence in the device's local time zone, strictly after now. */
    public long nextOccurrence(long nowMillis) {
        Calendar now=Calendar.getInstance(); now.setTimeInMillis(nowMillis);
        for (int delta=0; delta<=7; delta++) {
            Calendar c=(Calendar)now.clone(); c.add(Calendar.DAY_OF_MONTH,delta);
            c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute);
            c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            if (weekdaysMask!=0) {
                int bit=(c.get(Calendar.DAY_OF_WEEK)+5)%7; // SUN=1 => 6, MON=2 => 0
                if ((weekdaysMask&(1<<bit))==0) continue;
            }
            if (c.getTimeInMillis()>nowMillis+1000) return c.getTimeInMillis();
        }
        throw new IllegalStateException("no occurrence found");
    }
}
