package com.makiplayer.app.audioalarm;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Only local user-selected audio or directly playable authorised HTTPS media. NOT WebView pages. */
public final class AlarmMediaCatalog {
    public static final class Item {
        public final String title, uri;
        public Item(String title,String uri){this.title=title==null?"":title;this.uri=uri==null?"":uri;}
    }
    private final SharedPreferences prefs;
    public AlarmMediaCatalog(Context c){prefs=c.getApplicationContext().getSharedPreferences("maki_alarm_media_v1",Context.MODE_PRIVATE);}
    public static boolean supported(String raw){
        if(raw==null||raw.trim().isEmpty())return false;
        Uri uri=Uri.parse(raw);
        String scheme=uri.getScheme();
        return ("content".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
    }
    public List<Item> list(){
        List<Item> result=new ArrayList<>();
        try {
            JSONArray json=new JSONArray(prefs.getString("items","[]"));
            for(int i=0;i<json.length();i++) {
                JSONObject o=json.optJSONObject(i);
                if(o!=null&&supported(o.optString("uri")))result.add(new Item(o.optString("title","音频"),o.optString("uri")));
            }
        }catch(Exception ignore){}
        return result;
    }
    public synchronized void add(String title,String raw){
        if(!supported(raw))throw new IllegalArgumentException("Requires content:// or direct HTTPS audio URI");
        List<Item> items=list();
        for(Item i:items)if(i.uri.equals(raw)){saveLast(title,raw,0);return;}
        items.add(new Item(title,raw));
        JSONArray arr=new JSONArray();
        for(Item i:items){JSONObject o=new JSONObject();try{o.put("title",i.title);o.put("uri",i.uri);}catch(Exception e){throw new IllegalStateException(e);}arr.put(o);}
        if(!prefs.edit().putString("items",arr.toString()).commit())throw new IllegalStateException("media catalog save failed");
    }
    public void saveLast(String title,String uri,long positionMs){
        if(!supported(uri))throw new IllegalArgumentException("unsupported media URI");
        prefs.edit().putString("lastTitle",title==null?"":title).putString("lastUri",uri).putLong("lastPositionMs",Math.max(0,positionMs)).apply();
    }
    public Item resolve(AlarmSpec a){
        if(AlarmSpec.SPECIFIC.equals(a.sourceMode))return supported(a.mediaUri)?new Item(a.title,a.mediaUri):null;
        if(AlarmSpec.CONTINUE.equals(a.sourceMode)){
            String uri=prefs.getString("lastUri","");
            return supported(uri)?new Item(prefs.getString("lastTitle","继续播放"),uri):null;
        }
        List<Item> items=list();return items.isEmpty()?null:items.get(new Random().nextInt(items.size()));
    }
    public long lastPositionMs(){return Math.max(0,prefs.getLong("lastPositionMs",0));}
}
