package com.makiplayer.app.audioalarm;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Isolated preferences; never modifies existing Maki schema2/learning-v2.json. */
public final class AlarmStore {
    private static final String FILE="maki_alarm_module_v1";
    private final SharedPreferences prefs;
    public AlarmStore(Context context){prefs=context.getApplicationContext().getSharedPreferences(FILE,Context.MODE_PRIVATE);}
    public synchronized int nextId(){ int n=prefs.getInt("nextId",100)+1; prefs.edit().putInt("nextId",n).apply();return n;}
    public List<AlarmSpec> list(){
        List<AlarmSpec> result=new ArrayList<>();
        try {
            JSONArray arr=new JSONArray(prefs.getString("alarms","[]"));
            for(int i=0;i<arr.length();i++) try {
                JSONObject o=arr.getJSONObject(i);
                result.add(new AlarmSpec(o.getInt("id"),o.getInt("hour"),o.getInt("minute"),o.optInt("days",0),
                    o.optBoolean("enabled",true),o.optInt("duration",30),o.optInt("volume",60),
                    o.optBoolean("fade",true),o.optString("mode",AlarmSpec.CONTINUE),o.optString("title",""),o.optString("uri","")));
            } catch(Exception ignore) { /* invalid individual row must not hide valid alarms */ }
        }catch(Exception ignore){ /* a damaged new preferences value must not affect learning data */ }
        return result;
    }
    public AlarmSpec find(int id){for(AlarmSpec a:list())if(a.id==id)return a;return null;}
    public synchronized void put(AlarmSpec value){
        List<AlarmSpec> list=list(); boolean updated=false;
        for(int i=0;i<list.size();i++)if(list.get(i).id==value.id){list.set(i,value);updated=true;break;}
        if(!updated)list.add(value);
        write(list);
    }
    public synchronized void remove(int id){List<AlarmSpec> all=list();all.removeIf(a->a.id==id);write(all);}
    private void write(List<AlarmSpec> list){
        JSONArray arr=new JSONArray();
        for(AlarmSpec a:list){
            JSONObject o=new JSONObject();
            try {
                o.put("id",a.id);o.put("hour",a.hour);o.put("minute",a.minute);o.put("days",a.weekdaysMask);
                o.put("enabled",a.enabled);o.put("duration",a.durationMinutes);o.put("volume",a.targetVolume);
                o.put("fade",a.gradualVolume);o.put("mode",a.sourceMode);o.put("title",a.title);o.put("uri",a.mediaUri);
                arr.put(o);
            } catch(Exception e){throw new IllegalStateException(e);}
        }
        if(!prefs.edit().putString("alarms",arr.toString()).commit())
            throw new IllegalStateException("failed to save alarms");
    }
}
