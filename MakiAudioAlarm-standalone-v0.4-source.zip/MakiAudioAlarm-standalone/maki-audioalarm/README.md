# Maki 后台音频 + 自定义讲座闹钟模块 — 源码试验版 v0.1

**状态：代码已编写，独立纯 Java 时间逻辑测试通过；未编入 Maki 2.8 原工程，也未通过 Android 设备 / APK 端到端测试。**

## 当前交付（Android / Java 原生模块）
- 自定义多个闹钟：24 小时时间、周一到周日、单次、开关、编辑、删除。
- 精确闹钟：`AlarmManager.setAlarmClock()`，支持重新启动 / 系统时间变化 / 应用升级后重设；Android 12+ 未授权时提示用户授予“闹钟和提醒”权限，**不会暗自降级为不准时的闹钟**。
- 播放：Media3 `MediaSessionService` + `ExoPlayer` 后台音频、系统媒体控制、进度记忆；支持 `content://` 本地音频与合法的可直接播放的 `https://` 媒体；本地媒体文件使用系统文件选择器导入。
- 到点播放：首先在前台服务播放内置本地 WAV 铃声，若可解析并开始播放有声轨的媒体则切换到讲座音频；20 秒内无法播放时保持铃声；可选续播上次、指定导入音频、随机播放音频库。
- 自定义 0/10/20/30/60/120/240 分钟自动停止、目标播放器音量 10%-100%、30 秒渐强、通知按钮“停止”“贪睡 10 分钟”。
- 新数据单独写入 `maki_alarm_module_v1` / `maki_alarm_media_v1`，**不读取或修改**旧 `schema2`、`learning-v2.json`。源码没有更改应用签名 / 包名。
- 若部分 Android 系统不允许后台启动服务，接收器会尝试响铃通知兜底（有通知权限且系统允许时）；请勿将未实机验证版本作为唯一的起床闹钟。

## 重要界限
Maki 2.8 旧版使用 B 站 WebView 嵌入播放器，**并未获得可直接交给 Media3 的授权音频 URI**。WebView 内的普通视频页面不等于直连媒体地址。代码不绕过平台授权，也不从视频页提取私有音频 URL。因此“在原 B 站视频播放页上锁屏继续播放”目前**未实现**；这里只完成了**支持原生媒体的独立播放路径与自定义闹钟**。闹钟可以立即使用导入的本地音频，前提是接入原 Android 工程并通过真机验收。

## 集成到原 Maki 2.8 工程
1. **先备份原 `MakiPlayer-source.zip`、密钥、APK 和应用数据。** 保留原 `applicationId=com.makiplayer.app`、原签名证书、`schema2` 文件路径与数据迁移行为；本模块不会修改原持久层。
2. 将本文件夹放入工程 `maki-audioalarm/`。在原工程 `settings.gradle` 添加 `include ':maki-audioalarm'`；确保 settings 的 plugin management 能解析 Android Gradle plugin 且 repositories 包含 `google()`、`mavenCentral()`。
3. 在 `app/build.gradle` 添加 `implementation project(':maki-audioalarm')`，并确认 Media3 1.11.1 与原工程已有依赖的兼容性。原 `minSdk>=24` / `compileSdk>=35`。
4. Gradle 通过 manifest merger 合并本模块权限、服务、闹钟界面与广播接收器。若旧清单已有相同声明，合并处理冲突；不要直接覆盖主项目 manifest。
5. 在现有 `MainActivity` 的“设置 / 讲座闹钟”入口里调用 `MakiPlayback.openAlarmEditor(this);`。若主界面支持 `content://` 或授权的**直接**音频地址，在用户主动播放时可调用：

   ```java
   MakiPlayback.play(this, "示例讲座", playableAudioUri, 0L);
   ```

   仅对真实可播放的媒体 URI 调用，**不要**把官方 B 站视频网页 URL 直接传进来。
6. Android 13+ 允许通知权限以显示系统控制；Android 12+ 如系统拒绝精确闹钟权限，用户须在设置里明确同意。按实际手机系统验证电池限制。
7. 原工程如有播放进度可把授权音频继续位置传给 `MakiPlayback.play`；本模块使用自己的小型媒体目录供闹钟选择，未强行改写旧收藏数据。

## 运行本地测试（不需要 Android SDK）
```bash
./tests/run_model_tests.sh
```

## 尚未通过的验收项（必须真机完成）
- Gradle/AAPT/AGP 编译及 Android 24～35+ 的权限兼容性。
- 真实锁屏、退出 Maki、通知栏和耳机的播放/暂停；媒体音频焦点和音量。
- Android 14～16 的精准唤醒、重启自动恢复、锁屏/省电/OEM 后台限制、通知关闭、拒绝授权。
- 指定 / 随机 / 续播本地文件，音频失效、无网络、无声轨和异常恢复；闹钟声音是否真正响起。
- 与原 Maki 2.8 同包签名覆盖升级后，笔记、历史、收藏、播放器与数据迁移是否保留。
- B 站官方 WebView 音频后台及定时自动播放：**因平台限制与缺少原源码，仍为未实现。**

这是可集成源码试验版，不是已构建或通过真机测试的安装包。原工程当前不在可访问文件中。
