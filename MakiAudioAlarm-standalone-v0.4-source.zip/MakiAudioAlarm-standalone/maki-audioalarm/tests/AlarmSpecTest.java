import com.makiplayer.app.audioalarm.AlarmSpec;
import java.util.Calendar;
import java.util.TimeZone;

public final class AlarmSpecTest {
  static void check(boolean b,String why){ if(!b)throw new AssertionError(why); }
  static long at(int y,int month,int day,int hour,int minute){
    Calendar c=Calendar.getInstance(); c.clear(); c.set(y,month-1,day,hour,minute);return c.getTimeInMillis();
  }
  static AlarmSpec a(int mask){return new AlarmSpec(1,6,30,mask,true,30,60,true,AlarmSpec.CONTINUE,"","");}
  static void match(long millis,int y,int m,int d,int h,int min,String why){check(millis==at(y,m,d,h,min),why);}
  public static void main(String[]args){
    TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
    match(a(0).nextOccurrence(at(2026,10,25,5,0)),2026,10,25,6,30,"one-time today");
    match(a(0).nextOccurrence(at(2026,10,25,7,0)),2026,10,26,6,30,"one-time tomorrow");
    match(a(1).nextOccurrence(at(2026,10,25,7,0)),2026,10,26,6,30,"Sunday -> Monday");
    match(a(1).nextOccurrence(at(2026,10,26,6,31)),2026,11,2,6,30,"Monday -> next Monday");
    match(a(1<<6).nextOccurrence(at(2026,10,25,6,30)),2026,11,1,6,30,"Sunday -> next Sunday");
    match(a(31).nextOccurrence(at(2026,10,30,6,31)),2026,11,2,6,30,"weekdays Fri -> Mon");
    match(a(127).nextOccurrence(at(2026,10,25,6,29)),2026,10,25,6,30,"everyday today");
    check(a(127).nextOccurrence(at(2026,10,25,6,30))>at(2026,10,25,6,30),"no immediate duplicate");
    boolean failed=false;
    try{new AlarmSpec(1,25,0,0,true,10,50,false,AlarmSpec.CONTINUE,"","");}catch(IllegalArgumentException ex){failed=true;}
    check(failed,"reject invalid hour");
    System.out.println("9 alarm model assertions passed");
  }
}
