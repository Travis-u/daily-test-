#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
classes="$(mktemp -d)"; trap 'rm -rf "$classes"' EXIT
javac -d "$classes" "$here/src/main/java/com/makiplayer/app/audioalarm/AlarmSpec.java" "$here/tests/AlarmSpecTest.java"
java -cp "$classes" AlarmSpecTest
