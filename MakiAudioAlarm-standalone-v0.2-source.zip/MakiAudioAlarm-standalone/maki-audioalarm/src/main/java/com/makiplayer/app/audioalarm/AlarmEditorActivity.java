package com.makiplayer.app.audioalarm;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.List;

/** Native, completely user-editable alarm list and editor; does not depend on old Maki screens. */
public final class AlarmEditorActivity extends Activity {
    private static final int PICK_AUDIO=73;
    private LinearLayout root;
    private AlarmStore store;
    private final int[] durationOptions={0,10,20,30,60,120,240};
    private static final String[] modeNames={"续播上次音频","指定已导入音频","随机音频库"};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        store=new AlarmStore(this);
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(12),dp(18),dp(28));scroll.addView(root);
        setContentView(scroll);
        int editId=getIntent().getIntExtra("alarmId",-1);
        if(editId>0&&store.find(editId)!=null)showForm(store.find(editId));else showList();
    }
    @Override protected void onResume(){super.onResume(); if(store!=null)AlarmScheduler.rescheduleAll(this);}
    private int dp(int value){return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
    private void heading(String text){TextView v=new TextView(this);v.setText(text);v.setTextSize(23);v.setPadding(0,dp(8),0,dp(14));root.addView(v);}
    private TextView label(String text){TextView t=new TextView(this);t.setText(text);t.setTextSize(15);t.setPadding(0,dp(12),0,dp(4));root.addView(t);return t;}
    private Button button(String text,View.OnClickListener click){
        Button b=new Button(this);b.setText(text);b.setOnClickListener(click);root.addView(b);return b;
    }
    private void info(String text){TextView t=new TextView(this);t.setText(text);t.setTextSize(13);t.setPadding(0,dp(7),0,dp(12));root.addView(t);}
    private Spinner spinner(String[] values){
        Spinner s=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);
        s.setAdapter(adapter);root.addView(s);return s;
    }
    private String modeName(String m){return AlarmSpec.SPECIFIC.equals(m)?modeNames[1]:AlarmSpec.RANDOM.equals(m)?modeNames[2]:modeNames[0];}
    private void showList(){
        root.removeAllViews();heading("Maki · 讲座闹钟");
        info("可设置多个闹钟。网络/讲座无法播放时使用内置提示音；不会尝试绕过第三方视频播放器的限制。");
        button("＋ 新建闹钟",v->showForm(null));
        button("停止当前闹钟 / 音频",v->MakiPlayback.stop(this));
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            button("开启通知权限（停止 / 贪睡按钮）",v->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},32));
        }
        button("导入可播放的本地音频",v->selectAudio());
        List<AlarmSpec> alarms=store.list();
        if(alarms.isEmpty())info("暂时没有闹钟。可先导入音频，也可直接创建使用备用提示音的闹钟。");
        for(AlarmSpec a:alarms){
            LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.HORIZONTAL);line.setPadding(0,dp(8),0,dp(8));
            TextView desc=new TextView(this);
            desc.setText(String.format(java.util.Locale.CHINA,"%02d:%02d\n%s",a.hour,a.minute,repeat(a.weekdaysMask)));
            desc.setTextSize(18);line.addView(desc,new LinearLayout.LayoutParams(0,dp(66),1));
            Switch sw=new Switch(this);sw.setChecked(a.enabled);line.addView(sw);
            sw.setOnCheckedChangeListener((b,on)->{
                AlarmSpec n=a.withEnabled(on);store.put(n);
                if(!AlarmScheduler.schedule(this,n))permissionAlert();
            });
            root.addView(line);
            button("编辑 / 删除 · "+String.format(java.util.Locale.CHINA,"%02d:%02d",a.hour,a.minute),v->chooseActions(a));
        }
        info("特别说明：后台播放仅针对有合法直接播放地址的音频。本地文件最可靠；B站网页内的视频暂不能直接作为锁屏音频。");
    }
    private void chooseActions(AlarmSpec a){
        new AlertDialog.Builder(this).setTitle(String.format(java.util.Locale.CHINA,"%02d:%02d",a.hour,a.minute))
            .setItems(new String[]{"编辑","删除"},(d,which)->{
                if(which==0)showForm(a);
                else new AlertDialog.Builder(this).setMessage("删除该闹钟？")
                    .setPositiveButton("删除",(x,y)->{AlarmScheduler.cancel(this,a.id);store.remove(a.id);showList();})
                    .setNegativeButton("取消",null).show();
            }).show();
    }
    private static String repeat(int mask){
        if(mask==0)return "仅一次";
        if(mask==127)return "每天";
        if(mask==31)return "工作日";
        StringBuilder s=new StringBuilder("周");String days="一二三四五六日";
        for(int i=0;i<7;i++)if((mask&(1<<i))!=0)s.append(days.charAt(i));return s.toString();
    }
    private void showForm(AlarmSpec old){
        root.removeAllViews();heading(old==null?"新建讲座闹钟":"编辑讲座闹钟");
        button("停止当前响铃",v->MakiPlayback.stop(this));
        label("时间（24小时制）");
        TimePicker picker=new TimePicker(this);picker.setIs24HourView(true);
        picker.setHour(old==null?6:old.hour);picker.setMinute(old==null?30:old.minute);root.addView(picker);
        label("重复日期（全部不选＝仅一次）");
        LinearLayout weekRow=new LinearLayout(this);weekRow.setOrientation(LinearLayout.VERTICAL);
        CheckBox[] days=new CheckBox[7];String[] names={"星期一","星期二","星期三","星期四","星期五","星期六","星期日"};
        int mask=old==null?31:old.weekdaysMask;
        for(int i=0;i<7;i++){
            CheckBox b=new CheckBox(this);b.setText(names[i]);b.setChecked((mask&(1<<i))!=0);weekRow.addView(b);days[i]=b;
        }
        root.addView(weekRow);
        label("播放方式");Spinner mode=spinner(modeNames);
        mode.setSelection(old==null?0:AlarmSpec.SPECIFIC.equals(old.sourceMode)?1:AlarmSpec.RANDOM.equals(old.sourceMode)?2:0);
        label("指定音频（仅在指定模式使用）");
        List<AlarmMediaCatalog.Item> items=new AlarmMediaCatalog(this).list();
        String[] itemNames=new String[Math.max(1,items.size())];
        if(items.isEmpty())itemNames[0]="暂无音频，闹钟将播放备用提示音";
        else for(int i=0;i<items.size();i++)itemNames[i]=items.get(i).title;
        Spinner sources=spinner(itemNames);
        if(old!=null&&!items.isEmpty())for(int i=0;i<items.size();i++)if(items.get(i).uri.equals(old.mediaUri))sources.setSelection(i);
        button("＋ 导入本地音频（导入后回到列表再编辑）",v->selectAudio());
        label("播放时长");String[] dNames={"不自动停止","10 分钟","20 分钟","30 分钟","60 分钟","120 分钟","240 分钟"};
        Spinner durations=spinner(dNames);int initial=old==null?30:old.durationMinutes;
        for(int i=0;i<durationOptions.length;i++)if(durationOptions[i]==initial)durations.setSelection(i);
        label("目标音量（相对于媒体播放器音量，不强制修改系统音量）");
        TextView volumeText=label("");SeekBar volume=new SeekBar(this);volume.setMax(90);
        int v=old==null?60:old.targetVolume;volume.setProgress(v-10);volumeText.setText(v+"%");root.addView(volume);
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int val,boolean user){volumeText.setText((val+10)+"%");}
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
        CheckBox fade=new CheckBox(this);fade.setText("音量渐强（30 秒）");fade.setChecked(old==null||old.gradualVolume);root.addView(fade);
        CheckBox enabled=new CheckBox(this);enabled.setText("启用闹钟");enabled.setChecked(old==null||old.enabled);root.addView(enabled);
        button("保存闹钟",btn->{
            int daysMask=0;for(int i=0;i<7;i++)if(days[i].isChecked())daysMask|=(1<<i);
            String source=mode.getSelectedItemPosition()==1?AlarmSpec.SPECIFIC:mode.getSelectedItemPosition()==2?AlarmSpec.RANDOM:AlarmSpec.CONTINUE;
            String title="",uri="";
            if(AlarmSpec.SPECIFIC.equals(source)&&!items.isEmpty()){
                AlarmMediaCatalog.Item item=items.get(sources.getSelectedItemPosition());title=item.title;uri=item.uri;
            }
            int id=old==null?store.nextId():old.id;
            AlarmSpec a=new AlarmSpec(id,picker.getHour(),picker.getMinute(),daysMask,enabled.isChecked(),
                durationOptions[durations.getSelectedItemPosition()],volume.getProgress()+10,fade.isChecked(),source,title,uri);
            store.put(a);
            boolean ok=AlarmScheduler.schedule(this,a);
            showList();
            if(!ok)permissionAlert();else Toast.makeText(this,"闹钟已保存",Toast.LENGTH_SHORT).show();
        });
        button("取消",v->showList());
    }
    private void permissionAlert(){
        new AlertDialog.Builder(this).setTitle("需要精确闹钟权限")
            .setMessage("设置已保存，但系统尚未允许 Maki 准点响铃。请在系统设置里开启“闹钟和提醒”权限，然后返回。")
            .setPositiveButton("前往设置",(d,w)->{
                if(Build.VERSION.SDK_INT>=31){
                    Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .setData(Uri.parse("package:"+getPackageName()));
                    try{startActivity(i);}catch(Exception e){Toast.makeText(this,"请在系统设置中手动授予闹钟权限",Toast.LENGTH_LONG).show();}
                }
            }).setNegativeButton("稍后",null).show();
    }
    private void selectAudio(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_AUDIO);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=PICK_AUDIO||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}
        catch(SecurityException e){Toast.makeText(this,"文件授权无法永久保留，重启后可能不可用",Toast.LENGTH_LONG).show();}
        String title="本地音频";
        try(Cursor cursor=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(cursor!=null&&cursor.moveToFirst())title=cursor.getString(0);
        }catch(Exception ignored){}
        try{new AlarmMediaCatalog(this).add(title,uri.toString());
            Toast.makeText(this,"已导入音频："+title,Toast.LENGTH_SHORT).show();showList();}
        catch(Exception e){Toast.makeText(this,"导入失败，请更换音频文件",Toast.LENGTH_LONG).show();}
    }
}
